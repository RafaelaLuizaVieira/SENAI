function mostrarConteudo(id) {
    var conteudo = document.getElementById(id);
    var conteudos = document.getElementsByClassName('conteudo');

    for (var i = 0; i < conteudos.length; i++) {
        conteudos[i].style.display = 'none';
    }

    conteudo.style.display = 'block';
}