function menu(){
    window.location.href ="menu.html"
}
function emprestimo(){
    window.location.href ="emprestimos.html"
}