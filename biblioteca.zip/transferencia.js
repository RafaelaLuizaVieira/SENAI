function menu() {
    window.location.href ="biblioteca.html"
}
function gerenciador(){
    window.location.href="gerenciador.html"
}
function emprestimo(){
    window.location.href="emprestimos.html"
}